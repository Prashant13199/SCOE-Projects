Recently added face recognition software
========================================