Implementation of the LatentSVM detector algorithm
==================================================
