Tools for working with different datasets
=========================================