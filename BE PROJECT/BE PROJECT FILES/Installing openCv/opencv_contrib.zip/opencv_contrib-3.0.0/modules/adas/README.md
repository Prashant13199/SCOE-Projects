ADAS: Advanced Driver Assistance Systems module with Forward Collision Warning
==============================================================================