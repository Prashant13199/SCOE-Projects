/*
 * a rather innocuous-looking function which is actually
 * part of <cstdlib>, so we can be reasonably sure its
 * definition will be found
 */
#ifndef __OPENCV_MATLAB_TEST_GENERATOR_HPP_
#define __OPENCV_MATLAB_TEST_GENERATOR_HPP_

namespace cv {

CV_EXPORTS_W int rand( );

};

#endif
