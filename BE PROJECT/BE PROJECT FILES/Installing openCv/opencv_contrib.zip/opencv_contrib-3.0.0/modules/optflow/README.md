Optical Flow Algorithms for tracking points
===========================================